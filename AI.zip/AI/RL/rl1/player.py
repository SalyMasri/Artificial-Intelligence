#!/usr/bin/env python3
import random
import numpy as np

from agent import Fish
from communicator import Communicator
from shared import SettingLoader


class FishesModelling:
    def init_fishes(self, n):
        fishes = {}
        for i in range(n):
            fishes["fish" + str(i)] = Fish()
        self.fishes = fishes


class PlayerController(SettingLoader, Communicator):
    def __init__(self):
        SettingLoader.__init__(self)
        Communicator.__init__(self)
        self.space_subdivisions = 10
        self.actions = None
        self.action_list = None
        self.states = None
        self.init_state = None
        self.ind2state = None
        self.state2ind = None
        self.alpha = 0
        self.gamma = 0
        self.episode_max = 300

    def init_states(self):
        ind2state = {}
        state2ind = {}
        count = 0
        for row in range(self.space_subdivisions):
            for col in range(self.space_subdivisions):
                ind2state[(col, row)] = count
                state2ind[count] = [col, row]
                count += 1
        self.ind2state = ind2state
        self.state2ind = state2ind

    def init_actions(self):
        self.actions = {
            "left": (-1, 0),
            "right": (1, 0),
            "down": (0, -1),
            "up": (0, 1)
        }
        self.action_list = list(self.actions.keys())

    def allowed_movements(self):
        self.allowed_moves = {}
        for s in self.ind2state.keys():
            self.allowed_moves[self.ind2state[s]] = []
            if s[0] < self.space_subdivisions - 1:
                self.allowed_moves[self.ind2state[s]] += [1]
            if s[0] > 0:
                self.allowed_moves[self.ind2state[s]] += [0]
            if s[1] < self.space_subdivisions - 1:
                self.allowed_moves[self.ind2state[s]] += [3]
            if s[1] > 0:
                self.allowed_moves[self.ind2state[s]] += [2]

    def player_loop(self):
        pass


class PlayerControllerHuman(PlayerController):
    def player_loop(self):
        """
        Function that generates the loop of the game. In each iteration
        the human plays through the keyboard and send
        this to the game through the sender. Then it receives an
        update of the game through receiver, with this it computes the
        next movement.
        :return:
        """

        while True:
            # send message to game that you are ready
            msg = self.receiver()
            if msg["game_over"]:
                return


def epsilon_greedy(Q,
                   state,
                   all_actions,
                   current_total_steps=0,
                   epsilon_initial=1,
                   epsilon_final=0.2,
                   anneal_timesteps=10000,
                   eps_type="constant"):

    if eps_type == 'constant':
        epsilon = epsilon_final
        # ADD YOUR CODE SNIPPET BETWEEN EX 4.1
        # Implemenmt the epsilon-greedy algorithm for a constant epsilon value
        # Use epsilon and all input arguments of epsilon_greedy you see fit
        # It is recommended you use the np.random module
        action = None
        # ADD YOUR CODE SNIPPET BETWEEN EX 4.1

    elif eps_type == 'linear':
        # ADD YOUR CODE SNIPPET BETWEENEX  4.2
        # Implemenmt the epsilon-greedy algorithm for a linear epsilon value
        # Use epsilon and all input arguments of epsilon_greedy you see fit
        # use the ScheduleLinear class
        # It is recommended you use the np.random module
        action = None
        # ADD YOUR CODE SNIPPET BETWEENEX  4.2

    else:
        raise "Epsilon greedy type unknown"

    return action


class PlayerControllerRL(PlayerController, FishesModelling):
    def __init__(self):
        super().__init__()

    def player_loop(self):
        # Initialize states, actions, and settings
        self.init_actions()
        self.init_states()
        self.allowed_movements()
        self.alpha = self.settings.alpha
        self.gamma = self.settings.gamma
        self.epsilon_initial = self.settings.epsilon_initial
        self.epsilon_final = self.settings.epsilon_final
        self.annealing_timesteps = self.settings.annealing_timesteps
        self.threshold = self.settings.threshold
        self.episode_max = self.settings.episode_max

        # Train the agent using Q-learning
        Q = self.q_learning()

        # Compute the optimal policy from the Q-table
        policy = self.get_policy(Q)

        # Send the policy to the game
        msg = {"policy": policy, "exploration": False}
        self.sender(msg)

        # Wait for the game to acknowledge the policy
        msg = self.receiver()
        print("Q-learning Agent returning")
        return

    def q_learning(self):
        ns = len(self.state2ind.keys())
        na = len(self.actions.keys())
        Q = np.zeros((ns, na))  # Initialize Q-table

        # Initialize invalid actions in Q-table as NaN
        for s in range(ns):
            for a in range(na):
                if a not in self.allowed_moves[s]:
                    Q[s, a] = np.nan

        Q_old = Q.copy()
        episode = 0

        while episode <= self.episode_max:
            s_current = self.ind2state[
                (self.settings.init_pos_diver[0], self.settings.init_pos_diver[1])
            ]
            steps = 0
            R_total = 0
            end_episode = False

            while not end_episode and steps < self.settings.episode_len:
                # Epsilon-greedy action selection
                epsilon = max(
                    self.epsilon_final,
                    self.epsilon_initial - (episode / self.annealing_timesteps),
                )
                action = self.epsilon_greedy(Q, s_current, epsilon)

                # Send action to the game
                action_str = self.action_list[action]
                msg = {"action": action_str, "exploration": True}
                self.sender(msg)

                # Receive feedback from the game
                msg = self.receiver()
                R = msg["reward"]
                s_next_tuple = msg["state"]
                s_next = self.ind2state[s_next_tuple]
                end_episode = msg["end_episode"]

                # Update Q-values using the Bellman equation
                Q[s_current, action] += self.alpha * (
                    R + self.gamma * np.nanmax(Q[s_next]) - Q[s_current, action]
                )
                s_current = s_next
                steps += 1

            # Check for convergence
            diff = np.nanmean(np.abs(Q - Q_old))
            if diff < self.threshold:
                print(f"Converged after {episode} episodes.")
                break

            Q_old[:] = Q
            print(f"Episode: {episode}, Steps: {steps}, Diff: {diff:.2e}")
            episode += 1

        return Q

    def epsilon_greedy(self, Q, state, epsilon):
        if random.random() < epsilon:
            return random.choice(self.allowed_moves[state])
        else:
            return np.nanargmax(Q[state, :])

    def get_policy(self, Q):
        policy = {}
        for state in self.state2ind.keys():
            state_index = self.state2ind[state]
            best_action_index = np.nanargmax(Q[state_index])
            best_action = self.action_list[best_action_index]
            policy[state] = best_action
        return policy



class PlayerControllerRandom(PlayerController):
    def __init__(self):
        super().__init__()

    def player_loop(self):
        # Initialize actions, states, and allowed movements
        self.init_actions()
        self.init_states()
        self.allowed_movements()
        self.episode_max = self.settings.episode_max

        # Call the random agent logic
        n = self.random_agent()

        # Compute policy based on the most frequent action for each state
        policy = self.get_policy(n)

        # Send the computed policy to the game
        msg = {"policy": policy, "exploration": False}
        self.sender(msg)

        # Wait for the game to acknowledge the policy
        msg = self.receiver()
        print("Random Agent returning")
        return

    def random_agent(self):
        ns = len(self.state2ind.keys())
        na = len(self.actions.keys())
        n = np.zeros((ns, na), dtype=int)  # Initialize action counts

        init_pos_tuple = self.settings.init_pos_diver
        init_pos = self.ind2state[(init_pos_tuple[0], init_pos_tuple[1])]
        episode = 0

        while episode <= self.episode_max:
            s_current = init_pos
            steps = 0
            R_total = 0
            end_episode = False

            while not end_episode and steps < self.settings.episode_len:
                # Randomly select an action from allowed moves
                possible_actions = self.allowed_moves[s_current]
                action = random.choice(possible_actions)
                n[s_current][action] += 1  # Update action count

                # Send action to the game
                action_str = self.action_list[action]
                msg = {"action": action_str, "exploration": True}
                self.sender(msg)

                # Receive response from the game
                msg = self.receiver()
                R = msg["reward"]
                R_total += R
                s_next_tuple = msg["state"]
                end_episode = msg["end_episode"]
                s_current = self.ind2state[s_next_tuple]
                steps += 1

            print(f"Episode: {episode}, Steps: {steps}, Total Reward: {R_total}")
            episode += 1

        return n

    def get_policy(self, n):
        # Select the most frequent action for each state
        policy = {}
        for state in self.state2ind.keys():
            state_index = self.state2ind[state]
            best_action_index = np.argmax(n[state_index])
            best_action = self.action_list[best_action_index]
            policy[state] = best_action
        return policy



class ScheduleLinear(object):
    def __init__(self, schedule_timesteps, final_p, initial_p=1.0):
        self.schedule_timesteps = schedule_timesteps
        self.final_p = final_p
        self.initial_p = initial_p

    def value(self, t):
        # ADD YOUR CODE SNIPPET BETWEEN EX 4.2
        # Return the annealed linear value
        return self.initial_p
        # ADD YOUR CODE SNIPPET BETWEEN EX 4.2
